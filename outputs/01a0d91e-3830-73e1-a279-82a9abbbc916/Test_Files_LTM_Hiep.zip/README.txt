UDM10 - Bộ file mẫu cho test case của Tấn Hiệp

Giải nén ZIP trước khi chọn file trong Client. Các file .bin có kích thước đúng như tên; nội dung có mẫu lặp để ZIP gọn, phù hợp kiểm thử kích thước, chunk, queue, cancel và cleanup. File mẫu không phải dữ liệu ngẫu nhiên để benchmark hiệu năng chính thức.

00_file_rong.txt: kiểm tra file 0 byte.
01_file_nho_tieng_Viet_10KB.txt: kiểm tra file nhỏ, Unicode và tên file có tiếng Việt.
02_dung_mot_chunk_64KiB.bin: đúng một chunk cấu hình mặc định 65536 byte.
03_chunk_cong_1_byte_64KiB.bin: lớn hơn một chunk 1 byte.
04_file_1MiB.bin: upload nhỏ.
05_file_10MiB.bin: dùng để tạo bộ 10 file cho stress mức 1.
06_file_20MiB.bin: dùng để tạo bộ 30 file cho stress mức 2.
07_file_cancel_100MiB.bin: dùng cho cancel khi upload đang chạy.
08_trung_ten_A/bao_cao.txt và 08_trung_ten_B/bao_cao.txt: cùng tên, khác nội dung, dùng thử xử lý trùng tên.

Tạo bộ stress trên Windows PowerShell sau khi giải nén:

$src = Join-Path $PSScriptRoot '05_file_10MiB.bin'
$dst = Join-Path $PSScriptRoot 'stress_10x10MiB'
New-Item -ItemType Directory -Force $dst | Out-Null
1..10 | ForEach-Object { Copy-Item $src (Join-Path $dst ('file_{0:D2}_10MiB.bin' -f $_)) -Force }

$src = Join-Path $PSScriptRoot '06_file_20MiB.bin'
$dst = Join-Path $PSScriptRoot 'stress_30x20MiB'
New-Item -ItemType Directory -Force $dst | Out-Null
1..30 | ForEach-Object { Copy-Item $src (Join-Path $dst ('file_{0:D2}_20MiB.bin' -f $_)) -Force }

SHA-256 từng file được ghi trong manifest.json. File 10 MiB/20 MiB được sao chép với tên khác để tạo hàng đợi; nội dung trùng nhau là phù hợp với kiểm thử truyền và tải, nhưng không phù hợp để đo hiệu năng chính thức.
